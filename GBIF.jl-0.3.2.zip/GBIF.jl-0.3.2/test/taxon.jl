module TestSpecies

  using GBIF
  using Test

  iver = taxon("Iris versicolor", rank=:SPECIES)
  @test iver.species == Pair("Iris versicolor", 5298019)

  iver_id = taxon(5298019)  # test using taxon id
  @test iver_id.species == iver.species

  @test iver_id == taxon(Pair("Iris versicolor", 5298019))

  i_sp = taxon(iver.genus.first; rank=:GENUS, family=iver.family.first, strict=false)
  @test ismissing(i_sp.species)

  @test typeof(occurrences(i_sp)) <: GBIFRecords

  iver_occ = occurrences(iver)
  @test typeof(iver_occ) <: GBIFRecords
  for iocc in iver_occ
    @test iocc.taxon.species == Pair("Iris versicolor", 5298019)
  end

  iver_occ_spain = occurrences(iver, "country" => "ES")
  @test typeof(iver_occ_spain) <: GBIFRecords
  for iocc in iver_occ_spain
    @test iocc.taxon.species == Pair("Iris versicolor", 5298019)
    @test iocc.country == "Spain"
  end

end
