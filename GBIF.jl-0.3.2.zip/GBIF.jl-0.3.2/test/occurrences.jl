module TestGBIFRecords

  using GBIF
  using Test

  # Version using pairs
  set1 = occurrences("scientificName" => "Mus musculus", "year" => 1999, "hasCoordinate" => true)
  @test typeof(set1) == GBIFRecords
  @test length(set1) == 20

  # Version with no query parameters
  set2 = occurrences()
  @test typeof(set2) == GBIFRecords
  @test length(set2) == 20

  # Version using ranged pairs
  set3 = occurrences("scientificName" => "Mus musculus", "year" => 1999, "hasCoordinate" => true, "decimalLatitude" => (0.0,50.0))
  @test typeof(set3) == GBIFRecords
  @test length(set3) == 20

end
