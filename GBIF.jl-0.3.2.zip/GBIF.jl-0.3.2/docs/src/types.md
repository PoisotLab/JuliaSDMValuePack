# Data representation

```@docs
GBIFTaxon
GBIFRecord
GBIFRecords
```
