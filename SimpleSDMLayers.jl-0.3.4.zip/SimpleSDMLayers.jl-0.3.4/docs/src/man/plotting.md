# Plotting

Plotting currently supports (through Plots and StatsPlots) `heatmap` and
`contour` (for the values of a single layer), `density` and `histogram` (for the
non-`NaN` values), as well as `scatter` and `histogram2d` for two layers. All
usual options for plots apply. There are numerous illustrations of the plotting
functions in the examples.
