# Other operations

```@docs
coarsen
slidingwindow
latitudes
longitudes
clip
```
